package org.codehaus.jackson.impl;

/**
 * Deprecated version of the default pretty printer.
 * 
 * @deprecated Moved to {@link org.codehaus.jackson.util.DefaultPrettyPrinter}; will be removed in Jackson 2.0
 */
@Deprecated
public class DefaultPrettyPrinter
    extends org.codehaus.jackson.util.DefaultPrettyPrinter
{

}
